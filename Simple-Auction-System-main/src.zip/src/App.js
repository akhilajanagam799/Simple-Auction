import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import AuctionList from './components/AuctionList';
import Hero from './components/Hero';
import CreateAuctionModal from './components/CreateAuctionModal';
import HowItWorks from './components/HowItWorks';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';
import { getAuctionsFromLocal, saveAuctionsToLocal } from './utils/storage';
import Web3 from 'web3';
import './styles/app.css';

function App() {
  const [auctions, setAuctions] = useState([]);
  const auctionsRef = useRef([]);
  const [showModal, setShowModal] = useState(false);
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState(null);
  const [web3, setWeb3] = useState(null);

  useEffect(() => {
    auctionsRef.current = auctions;
  }, [auctions]);

  useEffect(() => {
    const initWeb3 = async () => {
      if (window.ethereum) {
        const web3Instance = new Web3(window.ethereum);
        setWeb3(web3Instance);
        try {
          const accounts = await web3Instance.eth.getAccounts();
          if (accounts.length > 0) {
            setWalletAddress(accounts[0]);
            setWalletConnected(true);
          }
        } catch (error) {
          console.error("Auto-connection failed:", error);
        }
      }
    };

    const loadStoredAuctions = () => {
      const storedAuctions = getAuctionsFromLocal();
      const now = Date.now();
      const initializedAuctions = storedAuctions.map((auction) => ({
        ...auction,
        createdAt: auction.createdAt || now,
        originalTimeLeft: auction.originalTimeLeft || auction.timeLeft || 3600,
        timeLeft: auction.timeLeft || auction.originalTimeLeft || 3600,
      }));
      setAuctions(initializedAuctions);
      auctionsRef.current = initializedAuctions;
      console.log("Loaded auctions from localStorage:", initializedAuctions);
    };

    initWeb3();
    loadStoredAuctions();

    const interval = setInterval(() => {
      const now = Date.now();
      const updatedAuctions = auctionsRef.current.map((auction) => {
        if (auction.createdAt && auction.originalTimeLeft !== undefined) {
          const elapsed = Math.floor((now - auction.createdAt) / 1000);
          const remaining = Math.max(0, auction.originalTimeLeft - elapsed);
          return { ...auction, timeLeft: remaining };
        }
        return auction;
      });

      setAuctions((prevAuctions) => {
        const changed = updatedAuctions.some((u, i) => u.timeLeft !== prevAuctions[i]?.timeLeft);
        if (changed) {
          saveAuctionsToLocal(updatedAuctions);
          auctionsRef.current = updatedAuctions;
          return updatedAuctions;
        }
        return prevAuctions;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const addAuction = (auctionData) => {
    if (!walletConnected) {
      alert("Please connect your wallet before creating an auction.");
      return;
    }

    const { name, startingBid, image } = auctionData;
    const timeLeft = parseTime(auctionData.timeInput);
    if (!timeLeft || timeLeft <= 0) {
      alert("Please enter a valid duration (e.g., '1h 30m' or '120s').");
      return;
    }

    const newAuction = {
      id: Date.now(),
      title: name,
      image,
      currentBid: `${startingBid} ETH`,
      bids: 0,
      timeLeft,
      originalTimeLeft: timeLeft,
      createdAt: Date.now(),
      category: 'art',
      creator: walletAddress || '0xAnonymous',
      avatar: `https://randomuser.me/api/portraits/men/${Math.floor(Math.random() * 100)}.jpg`,
    };

    const updatedAuctions = [...auctions, newAuction];
    setAuctions(updatedAuctions);
    auctionsRef.current = updatedAuctions;
    saveAuctionsToLocal(updatedAuctions);
    console.log("New auction added:", newAuction);
    setShowModal(false);
  };

  const parseTime = (input) => {
    try {
      if (!input) return 0;
      let totalSeconds = 0;
      const parts = input.toLowerCase().match(/(\d+(?:[.,]?\d+)?)[hms]/g) || [];
      parts.forEach(part => {
        const value = parseFloat(part);
        if (part.includes('h')) totalSeconds += value * 3600;
        if (part.includes('m')) totalSeconds += value * 60;
        if (part.includes('s')) totalSeconds += value;
      });
      return Math.max(0, Math.floor(totalSeconds));
    } catch (e) {
      console.error("Error parsing time:", e);
      return 0;
    }
  };

  const handleBidUpdate = (auctionId, bidAmount) => {
    if (!walletConnected) {
      alert("Please connect your wallet to place a bid.");
      return;
    }

    const updatedAuctions = auctions.map((auction) =>
      auction.id === auctionId
        ? { ...auction, currentBid: `${bidAmount} ETH`, bids: auction.bids + 1 }
        : auction
    );
    setAuctions(updatedAuctions);
    auctionsRef.current = updatedAuctions;
    saveAuctionsToLocal(updatedAuctions);
  };

  const connectWallet = async () => {
    if (!window.ethereum) {
      alert("MetaMask is not installed. Please install it to connect your wallet.");
      return;
    }

    try {
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      const accounts = await web3.eth.getAccounts();
      if (accounts.length > 0) {
        setWalletAddress(accounts[0]);
        setWalletConnected(true);
        alert(`Successfully connected wallet: ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`);
      } else {
        alert("No accounts found. Please unlock MetaMask.");
      }
    } catch (error) {
      console.error("Error connecting to MetaMask:", error);
      if (error.code === 4001) {
        alert("Wallet connection was rejected by the user.");
      } else {
        alert("Failed to connect wallet. Check MetaMask and try again.");
      }
    }
  };

  return (
    <>
      <Header onCreateClick={() => setShowModal(true)} onWalletConnect={connectWallet} walletConnected={walletConnected} />
      <Hero />
      <AuctionList auctions={auctions} onBid={handleBidUpdate} web3={web3} />
      {showModal && (
        <CreateAuctionModal
          onClose={() => setShowModal(false)}
          onCreate={addAuction}
          web3={web3}
          walletAddress={walletAddress}
        />
      )}
      <HowItWorks />
      <Newsletter />
      <Footer />
    </>
  );
}

export default App;
